package br.com.gerenciamento.model;

public @interface column {

    String name();

}
