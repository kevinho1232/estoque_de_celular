package br.com.gerenciamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciamentoCelularApplication {

    public static void main(String[] args) {
        SpringApplication.run(GerenciamentoCelularApplication.class, args);
    }
}
