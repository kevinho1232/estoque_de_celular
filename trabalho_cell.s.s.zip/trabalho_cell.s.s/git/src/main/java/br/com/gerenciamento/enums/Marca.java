package br.com.gerenciamento.enums;

public enum Marca {
    SAMSUNG, APPLE, MOTOROLA, LG, ASUS;
}
